// Team ACK!! -- Brian Kwong, Elaina Chung, Adrian Boylan
// APCS1 pd1
// HW30 -- Making a Role Playing Game
// 2016-11-16

public class Warrior 
{
    // instance vars
    private String name;
    private int HP;
    private int str;
    private int def;
    private double dmg;
    
    //constructor
    public Warrior(String n)
    {
	name = n;
	HP = 125;
	str = 100;
	def = 40;
	dmg = 0.4;
    }

    //returns boolean indicating living or dead when
    //true when HP is over 0, else false
    public boolean isAlive() 
    {
        return (HP > 0);
    }
    //returns name attribute
    public String getName() 
    {
	return name;
    }
    //returns defense attribute
    public int getDefense()
    {
	return def;
    }
    //decreases HP by HPlost
    public void lowerHP(int HPlost)
    {
	HP -= HPlost;
    }
    //lowers monster HP by int damage
    public int attack(Monster m) 
    {
	int damage = (int)(str * dmg) - m.getDefense();
	m.lowerHP(damage);
	return damage;
    }
    //def is decreased and dmg is increased
    public void specialize() 
    {
	def = 30;
	dmg = 0.5;
    }
    //def and dmg reset
    public void normalize() 
    {
	def = 40;
	dmg = 0.4;
    }
}
